# M21 rebuild profile

Target: Samsung Galaxy M21 / SM-M215F.

Build defaults:
- Device: `m21`
- ROM: `oneui`
- KernelSU: enabled
- SELinux: enforcing
- Optional external-module compatibility profile: `arch/arm64/configs/vendor/m21_compat.config`

The compatibility profile disables `CONFIG_MODVERSIONS`, removing kernel symbol CRC checks for external modules. It does **not** make arbitrary `.ko` files from 4.14.117/4.14.186 ABI-compatible with this 4.14.264 kernel. Rebuilding modules against this exact source/config remains the recommended approach.
